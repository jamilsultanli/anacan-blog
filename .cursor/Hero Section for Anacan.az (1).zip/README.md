
  # Hero Section for Anacan.az

  This is a code bundle for Hero Section for Anacan.az. The original project is available at https://www.figma.com/design/EpX3EQdq60KYE0EymQqV9u/Hero-Section-for-Anacan.az.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  